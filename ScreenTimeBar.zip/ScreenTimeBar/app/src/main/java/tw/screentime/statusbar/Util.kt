package tw.screentime.statusbar

import android.app.AppOpsManager
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process

object Perms {
    fun hasUsageAccess(ctx: Context): Boolean {
        val aom = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            aom.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        } else {
            @Suppress("DEPRECATION")
            aom.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        }
        return if (mode == AppOpsManager.MODE_DEFAULT) {
            ctx.checkCallingOrSelfPermission(android.Manifest.permission.PACKAGE_USAGE_STATS) ==
                PackageManager.PERMISSION_GRANTED
        } else {
            mode == AppOpsManager.MODE_ALLOWED
        }
    }

    fun notificationsEnabled(ctx: Context): Boolean =
        ctx.getSystemService(NotificationManager::class.java).areNotificationsEnabled()
}

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun isEnabled(c: Context) = sp(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()

    fun askedNotif(c: Context) = sp(c).getBoolean("asked_notif", false)
    fun setAskedNotif(c: Context) = sp(c).edit().putBoolean("asked_notif", true).apply()
}

object Fmt {
    fun long(ms: Long): String {
        val min = ms / 60_000
        val h = min / 60
        val m = min % 60
        return if (h > 0) "$h 小時 $m 分鐘" else "$m 分鐘"
    }

    fun short(ms: Long): String {
        val min = ms / 60_000
        val h = min / 60
        val m = min % 60
        return if (h > 0) "${h}時${m}分" else "${m}分"
    }
}
