package tw.screentime.statusbar

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.Icon

/**
 * 把使用時間畫成狀態列小圖示（兩行文字）：
 *   滿 1 小時：上「2h」、下「05m」
 *   未滿 1 小時：上「45」、下「min」
 * 系統只看透明度上色，所以用白字、透明底。
 */
object IconRenderer {
    private const val SIZE = 128
    private const val SPLIT = 76  // 上下兩行的分界

    fun render(totalMs: Long): Icon {
        val totalMin = totalMs / 60_000
        val h = totalMin / 60
        val m = totalMin % 60
        val top: String
        val bottom: String
        if (h > 0) {
            top = "${h}h"
            bottom = String.format("%02dm", m)
        } else {
            top = "$m"
            bottom = "min"
        }

        val bmp = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        drawFitted(canvas, paint, top, 0f, SPLIT.toFloat(), 84f)
        drawFitted(canvas, paint, bottom, SPLIT.toFloat(), SIZE.toFloat(), 52f)
        return Icon.createWithBitmap(bmp)
    }

    private fun drawFitted(c: Canvas, p: Paint, text: String, y0: Float, y1: Float, maxSize: Float) {
        p.textSize = maxSize
        val maxWidth = SIZE * 0.98f
        val w = p.measureText(text)
        if (w > maxWidth) p.textSize = maxSize * maxWidth / w
        val fm = p.fontMetrics
        val baseline = (y0 + y1) / 2f - (fm.ascent + fm.descent) / 2f
        c.drawText(text, SIZE / 2f, baseline, p)
    }
}
