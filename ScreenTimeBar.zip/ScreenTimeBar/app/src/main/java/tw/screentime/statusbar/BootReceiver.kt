package tw.screentime.statusbar

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** 開機或 App 更新後，如果之前有開啟，就自動恢復顯示。 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (!Prefs.isEnabled(context) || !Perms.hasUsageAccess(context)) return
        try {
            context.startForegroundService(Intent(context, UsageService::class.java))
        } catch (_: Exception) {
        }
    }
}
