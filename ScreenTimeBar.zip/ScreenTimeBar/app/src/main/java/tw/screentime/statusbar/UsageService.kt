package tw.screentime.statusbar

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder

/**
 * 前景服務：螢幕亮著時每分鐘重算一次，更新常駐通知的狀態列圖示。
 * 螢幕關掉就暫停，亮起時立刻更新，不額外耗電。
 */
class UsageService : Service() {

    companion object {
        const val CHANNEL_ID = "screen_time"
        const val NOTIF_ID = 1
        const val ACTION_STOP = "tw.screentime.statusbar.STOP"
        private const val INTERVAL_MS = 60_000L

        @Volatile
        var running = false
            private set
    }

    private lateinit var thread: HandlerThread
    private lateinit var handler: Handler
    private lateinit var nm: NotificationManager

    private val tick = object : Runnable {
        override fun run() {
            update()
            handler.postDelayed(this, INTERVAL_MS)
        }
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_ON, Intent.ACTION_USER_PRESENT -> restartTicking()
                Intent.ACTION_SCREEN_OFF -> {
                    handler.removeCallbacks(tick)
                    handler.post { update() }
                }
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        nm = getSystemService(NotificationManager::class.java)
        createChannel()

        val first = buildNotification(null)
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIF_ID, first, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(NOTIF_ID, first)
            }
        } catch (e: Exception) {
            // 系統不允許從背景啟動前景服務時（少數情況），直接結束
            stopSelf()
            return
        }
        running = true

        thread = HandlerThread("usage-calc").also { it.start() }
        handler = Handler(thread.looper)

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(screenReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(screenReceiver, filter)
        }

        handler.post(tick)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            Prefs.setEnabled(this, false)
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        if (running) restartTicking()
        return START_STICKY
    }

    override fun onDestroy() {
        if (running) {
            running = false
            try {
                unregisterReceiver(screenReceiver)
            } catch (_: Exception) {
            }
            handler.removeCallbacksAndMessages(null)
            thread.quitSafely()
        }
        super.onDestroy()
    }

    private fun restartTicking() {
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    private fun update() {
        val summary = if (Perms.hasUsageAccess(this)) {
            try {
                UsageCalculator.compute(this)
            } catch (e: Exception) {
                null
            }
        } else null
        nm.notify(NOTIF_ID, buildNotification(summary))
    }

    private fun createChannel() {
        // 預設重要性（但不響、不震動）：設為「靜音」等級的話，很多手機會把圖示從狀態列藏起來
        val ch = NotificationChannel(CHANNEL_ID, "螢幕使用時間", NotificationManager.IMPORTANCE_DEFAULT).apply {
            description = "在狀態列顯示今天的手機使用時間"
            setSound(null, null)
            enableVibration(false)
            enableLights(false)
            setShowBadge(false)
        }
        nm.createNotificationChannel(ch)
    }

    private fun buildNotification(s: UsageSummary?): Notification {
        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, UsageService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )

        val b = Notification.Builder(this, CHANNEL_ID)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setCategory(Notification.CATEGORY_STATUS)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setContentIntent(openApp)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, R.drawable.ic_stat_clock), "停止顯示", stop
                ).build()
            )
        if (Build.VERSION.SDK_INT >= 31) {
            b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
        }

        when {
            !Perms.hasUsageAccess(this) -> {
                b.setSmallIcon(R.drawable.ic_stat_clock)
                b.setContentTitle("需要「使用情況存取權」")
                b.setContentText("點這裡開啟 App 完成授權")
            }
            s == null -> {
                b.setSmallIcon(R.drawable.ic_stat_clock)
                b.setContentTitle("計算中…")
            }
            else -> {
                b.setSmallIcon(IconRenderer.render(s.totalMs))
                b.setContentTitle("今天已使用 ${Fmt.long(s.totalMs)}")
                if (s.topApps.isNotEmpty()) {
                    b.setContentText(s.topApps.take(3).joinToString("、") { "${it.label} ${Fmt.short(it.ms)}" })
                    b.setStyle(
                        Notification.BigTextStyle().bigText(
                            s.topApps.joinToString("\n") { "${it.label}　${Fmt.long(it.ms)}" }
                        )
                    )
                }
            }
        }
        return b.build()
    }
}
