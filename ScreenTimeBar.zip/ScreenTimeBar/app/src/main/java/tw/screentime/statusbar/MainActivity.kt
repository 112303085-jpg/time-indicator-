package tw.screentime.statusbar

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var usageStatus: TextView
    private lateinit var usageBtn: Button
    private lateinit var notifStatus: TextView
    private lateinit var notifBtn: Button
    private lateinit var toggleBtn: Button
    private lateinit var preview: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val density = resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }

        fun addText(size: Float, bold: Boolean = false, topGap: Int = 0): TextView {
            val tv = TextView(this)
            tv.textSize = size
            if (bold) tv.setTypeface(tv.typeface, Typeface.BOLD)
            tv.setPadding(0, dp(topGap), 0, dp(4))
            root.addView(tv)
            return tv
        }

        fun addButton(label: String, onClick: () -> Unit): Button {
            val btn = Button(this)
            btn.text = label
            btn.setOnClickListener { onClick() }
            root.addView(btn)
            return btn
        }

        addText(24f, bold = true).text = getString(R.string.app_name)
        addText(14f).text = "把今天的手機使用時間顯示在狀態列。先完成下面兩個授權，再按「開始顯示」。"

        usageStatus = addText(16f, bold = true, topGap = 20)
        usageBtn = addButton("開啟「使用情況存取權」設定") { openUsageSettings() }

        notifStatus = addText(16f, bold = true, topGap = 20)
        notifBtn = addButton("允許通知") { requestNotifications() }

        addText(16f, bold = true, topGap = 20).text = "③ 狀態列顯示"
        toggleBtn = addButton("開始顯示") { toggle() }
        addButton("（選用）關閉電池最佳化，避免被系統關掉") { openBatterySettings() }

        addText(16f, bold = true, topGap = 24).text = "今天的使用情況"
        preview = addText(15f)

        val scroll = ScrollView(this)
        scroll.addView(root)
        scroll.setOnApplyWindowInsetsListener { v, insets ->
            val (top, bottom) = systemBarInsets(insets)
            v.setPadding(0, top, 0, bottom)
            insets
        }
        setContentView(scroll)

        // Android 15 起畫面延伸到狀態列底下，改用深色狀態列圖示才看得到
        if (Build.VERSION.SDK_INT >= 35) {
            val flags = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
                WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
            window.insetsController?.setSystemBarsAppearance(flags, flags)
        }
    }

    @Suppress("DEPRECATION")
    private fun systemBarInsets(insets: WindowInsets): Pair<Int, Int> =
        if (Build.VERSION.SDK_INT >= 30) {
            val i = insets.getInsets(WindowInsets.Type.systemBars())
            i.top to i.bottom
        } else {
            insets.systemWindowInsetTop to insets.systemWindowInsetBottom
        }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }

    private fun refresh() {
        val usageOk = Perms.hasUsageAccess(this)
        val notifOk = Perms.notificationsEnabled(this)

        usageStatus.text = if (usageOk) "① ✅ 已取得使用情況存取權" else "① 開啟使用情況存取權（在清單中找到本 App 並開啟）"
        usageBtn.isEnabled = !usageOk
        notifStatus.text = if (notifOk) "② ✅ 已允許通知" else "② 允許通知"
        notifBtn.isEnabled = !notifOk

        toggleBtn.isEnabled = usageOk && notifOk
        toggleBtn.text = if (UsageService.running) "停止顯示" else "開始顯示"

        if (usageOk) {
            preview.text = "計算中…"
            Thread {
                val s = try {
                    UsageCalculator.compute(this)
                } catch (e: Exception) {
                    null
                }
                runOnUiThread { preview.text = describe(s) }
            }.start()
        } else {
            preview.text = "完成授權後就會顯示。"
        }
    }

    private fun describe(s: UsageSummary?): String {
        if (s == null) return "讀取失敗，請稍後再試。"
        val sb = StringBuilder("總計：${Fmt.long(s.totalMs)}\n")
        for (a in s.topApps) sb.append("\n• ${a.label}：${Fmt.long(a.ms)}")
        sb.append("\n\n（從今天 00:00 起算，不含桌面）")
        return sb.toString()
    }

    private fun toggle() {
        val intent = Intent(this, UsageService::class.java)
        if (UsageService.running) {
            Prefs.setEnabled(this, false)
            stopService(intent)
        } else {
            Prefs.setEnabled(this, true)
            startForegroundService(intent)
        }
        toggleBtn.postDelayed({ refresh() }, 400)
    }

    private fun openUsageSettings() {
        val withPkg = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS, Uri.parse("package:$packageName"))
        if (!tryStart(withPkg)) tryStart(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
    }

    private fun requestNotifications() {
        if (Build.VERSION.SDK_INT >= 33 && !Prefs.askedNotif(this)) {
            Prefs.setAskedNotif(this)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        } else {
            // 已經被拒絕過，系統不會再跳視窗，直接帶去通知設定
            tryStart(
                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            )
        }
    }

    private fun openBatterySettings() {
        tryStart(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
    }

    private fun tryStart(intent: Intent): Boolean = try {
        startActivity(intent)
        true
    } catch (e: Exception) {
        false
    }
}
