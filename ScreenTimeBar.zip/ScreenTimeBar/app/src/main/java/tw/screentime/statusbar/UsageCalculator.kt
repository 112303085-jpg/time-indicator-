package tw.screentime.statusbar

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.PowerManager
import java.util.Calendar

data class AppUsage(val packageName: String, val label: String, val ms: Long)

data class UsageSummary(val totalMs: Long, val topApps: List<AppUsage>)

/**
 * 從今天 00:00 起的使用事件，算出「App 在前景的時間」。
 *
 * - 用 queryEvents 逐筆配對「開到前景 / 離開前景」，比 queryUsageStats 的每日桶準確。
 * - 總時間取所有 App 前景區間的「聯集」，分割畫面時不會重複計算。
 * - 不計入預設桌面（啟動器），和「數位健康」的算法接近。
 */
object UsageCalculator {
    // 直接用數值，避免不同 API 版本的常數名稱差異
    private const val RESUMED = 1                 // ACTIVITY_RESUMED / MOVE_TO_FOREGROUND
    private const val PAUSED = 2                  // ACTIVITY_PAUSED / MOVE_TO_BACKGROUND
    private const val SCREEN_INTERACTIVE = 15     // 螢幕亮起
    private const val SCREEN_NON_INTERACTIVE = 16 // 螢幕關閉
    private const val KEYGUARD_SHOWN = 17         // 鎖定畫面出現
    private const val STOPPED = 23                // ACTIVITY_STOPPED
    private const val DEVICE_SHUTDOWN = 26        // 關機
    private const val DEVICE_STARTUP = 27         // 開機

    // 往前多讀 12 小時的事件，才能正確處理「午夜前打開、跨過 00:00」的 App
    private const val LOOKBACK_MS = 12 * 3_600_000L

    fun startOfToday(now: Long = System.currentTimeMillis()): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = now
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    fun compute(context: Context, topN: Int = 5): UsageSummary {
        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val dayStart = startOfToday(now)

        val open = HashMap<String, Long>()   // "套件/Activity" -> 進入前景時間
        val perApp = HashMap<String, MutableList<LongArray>>()

        // 只保留落在「今天 00:00 ~ 現在」的部分
        fun close(key: String, end: Long) {
            val start = open.remove(key) ?: return
            val s = maxOf(start, dayStart)
            val en = minOf(end, now)
            if (en > s) {
                perApp.getOrPut(key.substringBefore('/')) { ArrayList() }
                    .add(longArrayOf(s, en))
            }
        }

        fun closeAll(end: Long) {
            for (k in open.keys.toList()) close(k, end)
        }

        val events = usm.queryEvents(dayStart - LOOKBACK_MS, now)
            ?: return UsageSummary(0, emptyList())
        val e = UsageEvents.Event()
        var screenOn = true
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            val t = e.timeStamp
            when (e.eventType) {
                SCREEN_INTERACTIVE -> screenOn = true

                // 螢幕關閉、關機：所有 App 停止計時，而且螢幕亮起前不再開始計時
                SCREEN_NON_INTERACTIVE, DEVICE_SHUTDOWN -> {
                    closeAll(t)
                    screenOn = false
                }

                // 開機時螢幕是亮的（系統不一定會另外記錄「螢幕亮起」）
                DEVICE_STARTUP -> {
                    closeAll(t)
                    screenOn = true
                }

                KEYGUARD_SHOWN -> closeAll(t)

                RESUMED -> {
                    // 有些 App（例如微信）會在關螢幕時偷開一個看不見的畫面來保持在背景執行，
                    // 系統會把它記成「進入前景」。螢幕關著的時候一律不算。
                    if (!screenOn) continue
                    val pkg = e.packageName
                    // 換到另一個 App 時，其他 App 一定已經離開前景（即使系統漏記了「離開」）
                    for (k in open.keys.toList()) {
                        if (k.substringBefore('/') != pkg) close(k, t)
                    }
                    val key = pkg + "/" + e.className
                    if (key !in open) open[key] = t
                }

                PAUSED, STOPPED -> {
                    val pkg = e.packageName
                    val key = pkg + "/" + e.className
                    if (key in open) {
                        close(key, t)
                    } else if (e.eventType == PAUSED) {
                        // 名稱對不上時，結束同一個 App 所有還在計時的畫面
                        for (k in open.keys.toList()) {
                            if (k.substringBefore('/') == pkg) close(k, t)
                        }
                    }
                    // 完全沒有「進入」紀錄的「離開」直接忽略，不再從 00:00 起算
                }
            }
        }

        // 現在還在前景的 App 算到此刻為止（螢幕關著就不算）
        val power = context.getSystemService(PowerManager::class.java)
        if (power.isInteractive) closeAll(now)

        defaultLauncher(context)?.let { perApp.remove(it) }
        perApp.remove("android")
        perApp.remove("com.android.systemui")

        val all = ArrayList<LongArray>()
        val apps = ArrayList<Pair<String, Long>>()
        for ((pkg, list) in perApp) {
            all.addAll(list)
            val ms = unionLength(list)
            if (ms >= 1000) apps.add(pkg to ms)
        }
        apps.sortByDescending { it.second }

        val top = apps.take(topN).map { AppUsage(it.first, appLabel(context, it.first), it.second) }
        return UsageSummary(unionLength(all), top)
    }

    private fun unionLength(intervals: List<LongArray>): Long {
        if (intervals.isEmpty()) return 0
        val sorted = intervals.sortedBy { it[0] }
        var total = 0L
        var s = sorted[0][0]
        var e = sorted[0][1]
        for (i in 1 until sorted.size) {
            val a = sorted[i]
            if (a[0] <= e) {
                if (a[1] > e) e = a[1]
            } else {
                total += e - s
                s = a[0]
                e = a[1]
            }
        }
        return total + (e - s)
    }

    private fun defaultLauncher(context: Context): String? {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        return context.packageManager
            .resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
            ?.activityInfo?.packageName
    }

    private fun appLabel(context: Context, pkg: String): String = try {
        val pm = context.packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (e: PackageManager.NameNotFoundException) {
        pkg
    }
}
