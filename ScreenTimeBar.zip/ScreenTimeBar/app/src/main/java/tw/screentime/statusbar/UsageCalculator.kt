package tw.screentime.statusbar

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.PowerManager
import java.util.Calendar

data class AppUsage(val packageName: String, val label: String, val ms: Long)

data class UsageSummary(val totalMs: Long, val topApps: List<AppUsage>)

/**
 * 從今天 00:00 起的使用事件，算出「App 在前景的時間」。
 *
 * - 用 queryEvents 逐筆配對「開到前景 / 離開前景」，比 queryUsageStats 的每日桶準確。
 * - 總時間取所有 App 前景區間的「聯集」，分割畫面時不會重複計算。
 * - 不計入預設桌面（啟動器），和「數位健康」的算法接近。
 */
object UsageCalculator {
    // 直接用數值，避免不同 API 版本的常數名稱差異
    private const val RESUMED = 1                 // ACTIVITY_RESUMED / MOVE_TO_FOREGROUND
    private const val PAUSED = 2                  // ACTIVITY_PAUSED / MOVE_TO_BACKGROUND
    private const val SCREEN_NON_INTERACTIVE = 16 // 螢幕關閉
    private const val STOPPED = 23                // ACTIVITY_STOPPED
    private const val DEVICE_SHUTDOWN = 26        // 關機

    fun startOfToday(now: Long = System.currentTimeMillis()): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = now
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    fun compute(context: Context, topN: Int = 5): UsageSummary {
        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val dayStart = startOfToday(now)

        val open = HashMap<String, Long>()   // "套件/Activity" -> 進入前景時間
        val seen = HashSet<String>()
        val perApp = HashMap<String, MutableList<LongArray>>()

        fun close(key: String, end: Long) {
            val start = open.remove(key) ?: return
            if (end > start) {
                perApp.getOrPut(key.substringBefore('/')) { ArrayList() }
                    .add(longArrayOf(start, end))
            }
        }

        fun closeAll(end: Long) {
            for (k in open.keys.toList()) close(k, end)
        }

        val events = usm.queryEvents(dayStart, now) ?: return UsageSummary(0, emptyList())
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            val t = e.timeStamp
            when (e.eventType) {
                SCREEN_NON_INTERACTIVE, DEVICE_SHUTDOWN -> closeAll(t)

                RESUMED -> {
                    val key = e.packageName + "/" + e.className
                    seen.add(key)
                    if (key !in open) open[key] = t
                }

                PAUSED, STOPPED -> {
                    val key = e.packageName + "/" + e.className
                    // 午夜前就開著、跨過 00:00 的 App：今天第一筆是「離開」，從 00:00 起算
                    if (e.eventType == PAUSED && seen.add(key)) open[key] = dayStart
                    close(key, t)
                }
            }
        }

        // 現在還在前景的 App 算到此刻為止（螢幕關著就不算）
        val power = context.getSystemService(PowerManager::class.java)
        if (power.isInteractive) closeAll(now)

        defaultLauncher(context)?.let { perApp.remove(it) }
        perApp.remove("android")

        val all = ArrayList<LongArray>()
        val apps = ArrayList<Pair<String, Long>>()
        for ((pkg, list) in perApp) {
            all.addAll(list)
            val ms = unionLength(list)
            if (ms >= 1000) apps.add(pkg to ms)
        }
        apps.sortByDescending { it.second }

        val top = apps.take(topN).map { AppUsage(it.first, appLabel(context, it.first), it.second) }
        return UsageSummary(unionLength(all), top)
    }

    private fun unionLength(intervals: List<LongArray>): Long {
        if (intervals.isEmpty()) return 0
        val sorted = intervals.sortedBy { it[0] }
        var total = 0L
        var s = sorted[0][0]
        var e = sorted[0][1]
        for (i in 1 until sorted.size) {
            val a = sorted[i]
            if (a[0] <= e) {
                if (a[1] > e) e = a[1]
            } else {
                total += e - s
                s = a[0]
                e = a[1]
            }
        }
        return total + (e - s)
    }

    private fun defaultLauncher(context: Context): String? {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        return context.packageManager
            .resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
            ?.activityInfo?.packageName
    }

    private fun appLabel(context: Context, pkg: String): String = try {
        val pm = context.packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (e: PackageManager.NameNotFoundException) {
        pkg
    }
}
